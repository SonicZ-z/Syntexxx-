import { Hono } from 'hono'
import { cors } from 'hono/cors'

type Bindings = {
  OBFUSCATION_API_URL: string
  OBFUSCATION_V2_API_URL: string
}

const app = new Hono<{ Bindings: Bindings }>()
app.use('/api/*', cors())

let obfuscationCount = 14203
const viewers = new Map<string, number>()
const VIEWER_TIMEOUT = 15000

function cleanExpiredViewers() {
  const now = Date.now()
  for (const [id, ts] of viewers) { if (now - ts > VIEWER_TIMEOUT) viewers.delete(id) }
}

function generateApiKey(): string {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'
  let key = 'stx_'
  for (let i = 0; i < 40; i++) key += chars.charAt(Math.floor(Math.random() * chars.length))
  return key
}

const apiKeys = new Map<string, { createdAt: number; uses: number; label: string }>()

app.post('/api/keys/generate', async (c) => {
  const body = await c.req.json().catch(() => ({})) as Record<string, unknown>
  const label = (typeof body.label === 'string' ? body.label : 'Untitled') as string
  const key = generateApiKey()
  apiKeys.set(key, { createdAt: Date.now(), uses: 0, label })
  return c.json({ success: true, key, label })
})

app.get('/api/stats', (c) => {
  cleanExpiredViewers()
  return c.json({ totalProtected: obfuscationCount, liveViewers: viewers.size })
})

app.post('/api/heartbeat', async (c) => {
  const body = await c.req.json().catch(() => ({})) as Record<string, unknown>
  const vid = typeof body.vid === 'string' ? body.vid : ''
  if (vid) viewers.set(vid, Date.now())
  cleanExpiredViewers()
  return c.json({ liveViewers: viewers.size, totalProtected: obfuscationCount })
})

// Unified watermark for ALL versions
const WATERMARK = '--syntexxx.pages.dev << v2'

// Strip any upstream watermarks from obfuscated code
function stripWatermarks(code: string): string {
  let c = code
  // V1 upstream (klyra / points.baby)
  c = c.replace(/^--\s*Protected by klyra.*$/gim, '')
  c = c.replace(/^--\s*points\.baby\/obfuscator.*$/gim, '')
  // V2 upstream (goofyscator)
  c = c.replace(/^--\s*This file is protected by goofyscator.*$/gim, '')
  c = c.replace(/^--.*goofyscator\.lua\.cz.*$/gim, '')
  // Clean leftover blank lines at start
  c = c.replace(/^\s*\n/gm, '')
  return WATERMARK + '\n' + c
}

// Strip upstream branding from any string
function stripBranding(s: string): string {
  return s.replace(/klyra/gi, 'Syntexxx').replace(/points\.baby/gi, 'Syntexxx')
    .replace(/goofyscator/gi, 'Syntexxx').replace(/lua\.cz/gi, 'syntexxx.pages.dev')
}

// ─── V1 Obfuscation (Klyra) ───
async function obfuscateV1(apiUrl: string, code: string, options?: Record<string, unknown>, preset?: string) {
  const payload: Record<string, unknown> = { code }
  if (options) payload.options = options
  if (preset) payload.preset = preset

  const upstream = await fetch(apiUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  const data = await upstream.json() as Record<string, unknown>

  if (data.success && typeof data.code === 'string') {
    const obfuscatedCode = stripWatermarks(data.code as string)
    const stats = data.stats || {}
    let logs: Array<Record<string, unknown>> = []
    if (Array.isArray(data.logs)) {
      logs = (data.logs as Array<Record<string, unknown>>).map((log: Record<string, unknown>) => {
        const msg = typeof log.message === 'string' ? stripBranding(log.message as string) : log.message
        return { ...log, message: msg }
      })
    }
    return { success: true, code: obfuscatedCode, stats, logs }
  } else {
    return { success: false, error: 'Obfuscation failed. Check your code for syntax errors and try again.' }
  }
}

// ─── V2 Obfuscation (Goofyscator) ───
async function obfuscateV2(apiUrl: string, code: string, settings?: Record<string, unknown>) {
  const payload: Record<string, unknown> = { source: code }
  if (settings && typeof settings === 'object') payload.settings = settings

  const upstream = await fetch(apiUrl + '/obfuscate', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload)
  })
  const data = await upstream.json() as Record<string, unknown>

  if (data.status === 'success' && typeof data.result === 'string') {
    const obfuscatedCode = stripWatermarks(data.result as string)
    return { success: true, code: obfuscatedCode, stats: {}, logs: [] }
  } else {
    return { success: false, error: 'Obfuscation failed. Check your code for syntax errors and try again.' }
  }
}

// ─── Web UI obfuscate endpoint ───
app.post('/api/obfuscate', async (c) => {
  try {
    const body = await c.req.json() as Record<string, unknown>
    const { code, options, preset, apiKey, version, v2Settings } = body as {
      code?: string; options?: Record<string, unknown>; preset?: string
      apiKey?: string; version?: string; v2Settings?: Record<string, unknown>
    }

    if (!code || typeof code !== 'string' || code.trim().length === 0) {
      return c.json({ success: false, error: 'No code provided' }, 400)
    }

    if (apiKey && typeof apiKey === 'string') {
      const record = apiKeys.get(apiKey)
      if (!record) return c.json({ success: false, error: 'Invalid API key' }, 401)
      record.uses++
    }

    let result: Record<string, unknown>

    if (version === 'v2') {
      const apiUrl = c.env.OBFUSCATION_V2_API_URL
      result = await obfuscateV2(apiUrl, code, v2Settings)
    } else {
      const apiUrl = c.env.OBFUSCATION_API_URL
      result = await obfuscateV1(apiUrl, code, options, preset)
    }

    if (result.success) {
      obfuscationCount++
      return c.json({ ...result, totalProtected: obfuscationCount })
    }
    return c.json(result)
  } catch (err: unknown) {
    return c.json({ success: false, error: 'Obfuscation failed. Please try again later.' }, 502)
  }
})

// ─── External API ───
app.post('/api/v1/obfuscate', async (c) => {
  const authHeader = c.req.header('Authorization')
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return c.json({ success: false, error: 'Missing or invalid Authorization header. Use: Bearer stx_...' }, 401)
  }
  const key = authHeader.replace('Bearer ', '').trim()
  const record = apiKeys.get(key)
  if (!record) return c.json({ success: false, error: 'Invalid API key' }, 401)

  try {
    const body = await c.req.json() as Record<string, unknown>
    const { code, options, preset, version, v2Settings } = body as {
      code?: string; options?: Record<string, unknown>; preset?: string
      version?: string; v2Settings?: Record<string, unknown>
    }
    if (!code || typeof code !== 'string' || code.trim().length === 0) {
      return c.json({ success: false, error: 'No code provided' }, 400)
    }
    record.uses++

    let result: Record<string, unknown>
    if (version === 'v2') {
      result = await obfuscateV2(c.env.OBFUSCATION_V2_API_URL, code, v2Settings)
    } else {
      result = await obfuscateV1(c.env.OBFUSCATION_API_URL, code, options, preset)
    }
    if (result.success) obfuscationCount++
    return c.json(result)
  } catch (err: unknown) {
    return c.json({ success: false, error: 'Obfuscation failed. Please try again later.' }, 502)
  }
})

// ─── Pages ───
app.get('/', (c) => c.html(mainPage()))
app.get('/terms', (c) => c.html(termsPage()))
app.get('/privacy', (c) => c.html(privacyPage()))

// ─── Shared ───
function pageHead(title: string) {
  return `<!DOCTYPE html><html lang="en"><head>
  <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title}</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;500;600;700&family=Inter:wght@300;400;500;600;700;800;900&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css" rel="stylesheet">
  <style>${mainCSS()}</style></head><body><div class="noise-overlay"></div>`
}

function navBar() {
  return `<header><nav>
    <a href="/" class="logo"><span class="logo-icon">&#x2B21;</span><span class="logo-text">Syntexxx</span></a>
    <div class="nav-links">
      <a href="/#obfuscator" class="nav-link">Obfuscator</a>
      <a href="/#features" class="nav-link">Features</a>
      <a href="https://youtube.com/@sonicz-dev?si=gYlCjUugPIICIUn_" target="_blank" rel="noopener" class="nav-link credit-link"><i class="fab fa-youtube"></i> SonicZ Dev</a>
    </div>
  </nav></header>`
}

function pageFooter() {
  return `<footer><div class="container">
    <div class="footer-content">
      <div class="footer-brand"><span class="logo-icon">&#x2B21;</span> Syntexxx</div>
      <div class="footer-center-links"><a href="/terms">Terms of Service</a><a href="/privacy">Privacy Policy</a></div>
      <div class="footer-links"><a href="https://youtube.com/@sonicz-dev?si=gYlCjUugPIICIUn_" target="_blank" rel="noopener"><i class="fab fa-youtube"></i> Credits: SonicZ Dev</a></div>
    </div>
    <div class="footer-copy">&copy; 2024 Syntexxx. All rights reserved.</div>
  </div></footer>`
}

function mainPage() {
  return `${pageHead('Syntexxx — Lua Obfuscator')}
  ${navBar()}

  <section class="hero"><div class="hero-grid"></div>
    <div class="hero-content">
      <div class="hero-badge">LUA &amp; LUAU OBFUSCATION</div>
      <h1><span class="hero-line">Protect Your</span><span class="hero-line accent">Lua Scripts</span></h1>
      <p class="hero-sub">Obfuscate your Lua and Luau source code with LuaVM virtualization, string encryption, control flow flattening, and more.</p>
      <div class="hero-actions">
        <a href="#obfuscator" class="btn btn-primary">Start Obfuscating</a>
      </div>
      <div class="live-counters">
        <div class="counter-box"><div class="counter-number" id="global-counter">0</div><div class="counter-label">Scripts Protected</div></div>
        <div class="counter-divider"></div>
        <div class="counter-box"><div class="counter-number" id="live-viewers">0</div><div class="counter-label"><span class="pulse-dot"></span> Viewing Now</div></div>
      </div>
    </div>
  </section>

  <section class="info-section" id="about"><div class="container">
    <h2 class="section-title">What is Syntexxx?</h2>
    <div class="info-grid">
      <div class="info-card"><h3>Lua Obfuscator</h3><p>Syntexxx takes your readable Lua or Luau code and transforms it into a version that works exactly the same but is extremely difficult to read or reverse-engineer.</p></div>
      <div class="info-card"><h3>How it works</h3><p>Paste your code, pick your version and settings, hit obfuscate. Your code gets processed through multiple protection layers and you get the protected version back in seconds.</p></div>
      <div class="info-card"><h3>Who is it for</h3><p>Roblox developers, Lua game devs, anyone who ships Lua scripts and wants to keep their source code private. Works with both standard Lua and Luau.</p></div>
      <div class="info-card"><h3>Two Engines</h3><p>Choose between V1 (LuaVM virtualization with deep nesting) or V2 (Syntexxx.of.to v2 — fast AST-level protection with string encryption and control flow).</p></div>
    </div>
  </div></section>

  <section class="features" id="features"><div class="container">
    <h2 class="section-title">What You Get</h2>
    <div class="features-grid">
      <div class="feature-card"><div class="feature-icon"><i class="fas fa-microchip"></i></div><h3>LuaVM Virtualization</h3><p>Converts your code into custom bytecode that runs inside a virtual machine with shuffled opcodes.</p></div>
      <div class="feature-card"><div class="feature-icon"><i class="fas fa-lock"></i></div><h3>String Encryption</h3><p>All string literals are encrypted and only decoded when needed at runtime. Nothing in plaintext.</p></div>
      <div class="feature-card"><div class="feature-icon"><i class="fas fa-shuffle"></i></div><h3>Control Flow Flattening</h3><p>Breaks the normal flow of your code into scrambled state-machine blocks so decompilers can't follow it.</p></div>
      <div class="feature-card"><div class="feature-icon"><i class="fas fa-shield-halved"></i></div><h3>Anti-Tamper</h3><p>Integrity checks that detect if someone tries to modify or hook into your protected script.</p></div>
      <div class="feature-card"><div class="feature-icon"><i class="fas fa-masks-theater"></i></div><h3>Proxy Wrapping</h3><p>Variables and functions get wrapped through metatable proxies, adding another layer of confusion.</p></div>
      <div class="feature-card"><div class="feature-icon"><i class="fas fa-compress"></i></div><h3>Minification</h3><p>Removes comments, debug info, and renames all identifiers to short meaningless names.</p></div>
    </div>
  </div></section>

  <section class="coming-soon-section" id="js-obfuscation"><div class="container">
    <div class="coming-soon-card">
      <div class="coming-soon-icon"><i class="fab fa-js-square"></i></div>
      <h2>JavaScript Obfuscation</h2>
      <p>Protect your JavaScript source code with the same level of obfuscation. Variable renaming, string encoding, control flow flattening, and dead code injection for JS.</p>
      <div class="coming-soon-badge">Coming Soon</div>
    </div>
  </div></section>

  <section class="obfuscator" id="obfuscator"><div class="container">
    <h2 class="section-title">Obfuscate Now</h2>
    <div class="obf-layout">
      <aside class="options-panel">
        <h3><i class="fas fa-sliders"></i> Settings</h3>

        <!-- Version selector -->
        <div class="option-group version-selector">
          <label class="toggle-label"><span>Engine</span></label>
          <div class="version-tabs">
            <button class="version-tab active" data-version="v1" id="tab-v1">V1</button>
            <button class="version-tab" data-version="v2" id="tab-v2">V2</button>
          </div>
        </div>

        <!-- V1 Options -->
        <div id="v1-options">
          <div class="option-group"><label class="toggle-label"><span>LuaVM</span><label class="toggle"><input type="checkbox" id="opt-useLuaVM" checked><span class="toggle-slider"></span></label></label></div>
          <div class="option-group"><label class="range-label"><span>VM Depth</span><span id="depth-val" class="range-val">3</span></label><input type="range" id="opt-loaderVMDepth" min="1" max="5" value="3" class="range-input"></div>
          <div class="option-group"><label class="toggle-label"><span>Encrypt Strings</span><label class="toggle"><input type="checkbox" id="opt-encryptStrings" checked><span class="toggle-slider"></span></label></label></div>
          <div class="option-group"><label class="toggle-label"><span>Proxify Locals</span><label class="toggle"><input type="checkbox" id="opt-proxifyLocals" checked><span class="toggle-slider"></span></label></label></div>
          <div class="option-group"><label class="toggle-label"><span>Proxify Functions</span><label class="toggle"><input type="checkbox" id="opt-proxifyFunctions" checked><span class="toggle-slider"></span></label></label></div>
          <div class="option-group"><label class="toggle-label"><span>Anti-Tamper</span><label class="toggle"><input type="checkbox" id="opt-antiTamper" checked><span class="toggle-slider"></span></label></label></div>
          <div class="option-group"><label class="toggle-label"><span>Luau Runtime</span><label class="toggle"><input type="checkbox" id="opt-isLuauRuntime" checked><span class="toggle-slider"></span></label></label></div>
          <div class="option-group"><label class="toggle-label"><span>Control Flow</span><label class="toggle"><input type="checkbox" id="opt-controlFlowFlattening" checked><span class="toggle-slider"></span></label></label></div>
          <div class="option-group"><label class="toggle-label"><span>Minify</span><label class="toggle"><input type="checkbox" id="opt-minify" checked><span class="toggle-slider"></span></label></label></div>
        </div>

        <!-- V2 Options -->
        <div id="v2-options" style="display:none">
          <div class="option-group"><label class="toggle-label"><span>Encrypt Strings</span><label class="toggle"><input type="checkbox" id="v2-encryptStrings" checked><span class="toggle-slider"></span></label></label></div>
          <div class="option-group"><label class="toggle-label"><span>Proxify Locals</span><label class="toggle"><input type="checkbox" id="v2-proxifyLocals" checked><span class="toggle-slider"></span></label></label></div>
          <div class="option-group"><label class="toggle-label"><span>Proxify Functions</span><label class="toggle"><input type="checkbox" id="v2-proxifyFunctions" checked><span class="toggle-slider"></span></label></label></div>
          <div class="option-group"><label class="toggle-label"><span>Anti-Tamper</span><label class="toggle"><input type="checkbox" id="v2-antiTamper" checked><span class="toggle-slider"></span></label></label></div>
          <div class="option-group"><label class="toggle-label"><span>Control Flow</span><label class="toggle"><input type="checkbox" id="v2-controlFlowFlattening" checked><span class="toggle-slider"></span></label></label></div>
          <div class="option-group"><label class="toggle-label"><span>Luau Runtime</span><label class="toggle"><input type="checkbox" id="v2-isLuauRuntime" checked><span class="toggle-slider"></span></label></label></div>
          <div class="option-group"><label class="range-label"><span>VM Depth</span><span id="v2-depth-val" class="range-val">3</span></label><input type="range" id="v2-loaderVMDepth" min="1" max="5" value="3" class="range-input"></div>
        </div>

        <button id="btn-obfuscate" class="btn btn-primary btn-full"><i class="fas fa-shield-halved"></i> Obfuscate</button>
      </aside>

      <div class="code-panels">
        <div class="code-panel"><div class="panel-header"><span><i class="fas fa-code"></i> Input</span><button id="btn-clear" class="btn-icon" title="Clear"><i class="fas fa-eraser"></i></button></div>
          <textarea id="code-input" spellcheck="false" placeholder="-- Paste your Lua / Luau code here&#10;local function hello()&#10;  print('Hello, World!')&#10;end&#10;hello()"></textarea></div>
        <div class="code-panel"><div class="panel-header"><span><i class="fas fa-shield-halved"></i> Protected Output</span><button id="btn-copy" class="btn-icon" title="Copy"><i class="fas fa-copy"></i></button></div>
          <textarea id="code-output" spellcheck="false" readonly placeholder="-- Your obfuscated code will appear here..."></textarea></div>
      </div>
    </div>

    <div class="stats-bar" id="stats-bar" style="display:none">
      <div class="stat-item"><i class="fas fa-file-code"></i> Input: <span id="stat-input-bytes">0</span> bytes</div>
      <div class="stat-item"><i class="fas fa-shield"></i> Output: <span id="stat-output-bytes">0</span> bytes</div>
      <div class="stat-item"><i class="fas fa-clock"></i> Time: <span id="stat-time">0</span>s</div>
    </div>
    <div class="logs-container" id="logs-container" style="display:none"><h4><i class="fas fa-terminal"></i> Build Log</h4><div id="logs-output" class="logs-output"></div></div>
    <div class="error-container" id="error-container" style="display:none"><div id="error-output"></div></div>
  </div></section>

  <section class="api-key-section" id="api-key-section"><div class="container">
    <h2 class="section-title">Get Your API Key</h2>
    <p class="section-sub">Generate a free API key to use Syntexxx obfuscation in your own tools or scripts.</p>
    <div class="api-key-box">
      <div class="api-key-form"><input type="text" id="key-label" placeholder="Label (e.g. My Project)" class="input-field"><button id="btn-gen-key" class="btn btn-primary"><i class="fas fa-key"></i> Generate Key</button></div>
      <div id="generated-key" class="generated-key" style="display:none"><code id="key-value"></code><button id="btn-copy-key" class="btn-icon" title="Copy"><i class="fas fa-copy"></i></button></div>
    </div>
  </div></section>

  ${pageFooter()}
  <script>${mainJS()}</script>
</body></html>`
}

function termsPage() {
  return `${pageHead('Syntexxx — Terms of Service')}${navBar()}
  <section class="legal-page"><div class="container">
    <h1 class="section-title">Terms of Service</h1><p class="legal-updated">Last updated: September 2024</p>
    <div class="legal-content">
      <h2>1. Acceptance of Terms</h2><p>By accessing or using Syntexxx ("the Service"), you agree to be bound by these Terms of Service.</p>
      <h2>2. Description of Service</h2><p>Syntexxx provides a Lua and Luau code obfuscation service, available through a web interface and a REST API.</p>
      <h2>3. Acceptable Use</h2><p>You agree to use the Service only for lawful purposes. You may not:</p><ul><li>Use the Service to obfuscate malicious code, malware, or exploits.</li><li>Attempt to overload or disrupt the Service's infrastructure.</li><li>Use automated systems to abuse the Service.</li><li>Resell or redistribute the Service as your own without permission.</li></ul>
      <h2>4. API Keys</h2><p>API keys are provided free of charge. You are responsible for keeping your API key secure. We reserve the right to revoke keys that are being misused.</p>
      <h2>5. Code Ownership</h2><p>You retain full ownership of any code you submit. We do not store, log, or retain your source code beyond what is needed to process the request.</p>
      <h2>6. No Warranty</h2><p>The Service is provided "as is" without warranties of any kind.</p>
      <h2>7. Limitation of Liability</h2><p>Syntexxx shall not be liable for any damages arising from your use of the Service.</p>
      <h2>8. Changes to Terms</h2><p>We may update these Terms at any time. Continued use means you accept the updated Terms.</p>
    </div>
  </div></section>${pageFooter()}</body></html>`
}

function privacyPage() {
  return `${pageHead('Syntexxx — Privacy Policy')}${navBar()}
  <section class="legal-page"><div class="container">
    <h1 class="section-title">Privacy Policy</h1><p class="legal-updated">Last updated: September 2024</p>
    <div class="legal-content">
      <h2>1. Overview</h2><p>This Privacy Policy explains what information Syntexxx collects and how we use it.</p>
      <h2>2. Information We Collect</h2>
      <p><strong>Code submissions:</strong> We do not store, log, or retain your source code after the request is completed.</p>
      <p><strong>API keys:</strong> We store the key and an optional label. We track usage counts.</p>
      <p><strong>Usage statistics:</strong> Aggregate counters only. No identifying information.</p>
      <h2>3. Data Sharing</h2><p>We do not sell, rent, or share your information with third parties.</p>
      <h2>4. Cookies</h2><p>The Service does not use tracking cookies.</p>
      <h2>5. Data Security</h2><p>All communication is encrypted over HTTPS.</p>
      <h2>6. Changes</h2><p>We may update this policy from time to time.</p>
    </div>
  </div></section>${pageFooter()}</body></html>`
}

function mainCSS() {
  return `
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#000;--bg-subtle:#0a0a0a;--bg-card:#111;--bg-card-hover:#181818;--border:#222;--border-hover:#333;--text:#fff;--text-muted:#888;--text-dim:#555;--radius:10px;--radius-lg:16px;--font-sans:'Inter',system-ui,sans-serif;--font-mono:'JetBrains Mono',monospace;--transition:150ms ease}
html{scroll-behavior:smooth;background:var(--bg);color:var(--text);font-family:var(--font-sans)}
body{min-height:100vh;overflow-x:hidden;-webkit-font-smoothing:antialiased}
a{color:var(--text);text-decoration:none}
::selection{background:#fff;color:#000}
.noise-overlay{position:fixed;top:0;left:0;width:100%;height:100%;z-index:9999;pointer-events:none;background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n' x='0' y='0'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='256' height='256' filter='url(%23n)' opacity='0.03'/%3E%3C/svg%3E");opacity:0.4}
.container{max-width:1200px;margin:0 auto;padding:0 24px}
header{position:fixed;top:0;left:0;right:0;z-index:100;backdrop-filter:blur(20px);background:rgba(0,0,0,0.7);border-bottom:1px solid var(--border)}
nav{display:flex;align-items:center;justify-content:space-between;max-width:1200px;margin:0 auto;padding:16px 24px}
.logo{display:flex;align-items:center;gap:10px;font-weight:800;font-size:1.25rem;letter-spacing:-0.5px}
.logo-icon{font-size:1.5rem;opacity:0.8}
.nav-links{display:flex;align-items:center;gap:28px}
.nav-link{font-size:0.875rem;font-weight:500;color:var(--text-muted);transition:color var(--transition)}
.nav-link:hover,.nav-link.active{color:var(--text)}
.credit-link{color:#ff4444;font-weight:600}.credit-link:hover{color:#ff6666}
.hero{position:relative;min-height:100vh;display:flex;align-items:center;justify-content:center;overflow:hidden;padding:120px 24px 80px}
.hero-grid{position:absolute;inset:0;background-image:linear-gradient(rgba(255,255,255,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.03) 1px,transparent 1px);background-size:60px 60px;mask-image:radial-gradient(ellipse 60% 50% at 50% 50%,#000 40%,transparent 100%)}
.hero-content{text-align:center;position:relative;z-index:1;max-width:800px}
.hero-badge{display:inline-block;font-size:0.7rem;font-weight:700;letter-spacing:3px;color:var(--text-muted);border:1px solid var(--border);padding:8px 20px;border-radius:100px;margin-bottom:32px;text-transform:uppercase}
.hero h1{font-size:clamp(3rem,8vw,6rem);font-weight:900;line-height:1;letter-spacing:-3px;margin-bottom:24px}
.hero-line{display:block}.hero-line.accent{background:linear-gradient(135deg,#fff 0%,#666 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text}
.hero-sub{font-size:1.125rem;color:var(--text-muted);max-width:560px;margin:0 auto 40px;line-height:1.7}
.hero-actions{display:flex;gap:16px;justify-content:center;flex-wrap:wrap;margin-bottom:48px}
.live-counters{display:flex;gap:40px;justify-content:center;align-items:center}
.counter-box{text-align:center}
.counter-number{font-size:3rem;font-weight:900;letter-spacing:-2px;font-family:var(--font-mono);background:linear-gradient(135deg,#fff 0%,#888 100%);-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;line-height:1.2}
.counter-label{font-size:0.75rem;color:var(--text-muted);text-transform:uppercase;letter-spacing:2px;margin-top:4px;display:flex;align-items:center;justify-content:center;gap:6px}
.counter-divider{width:1px;height:60px;background:var(--border)}
.pulse-dot{width:8px;height:8px;border-radius:50%;background:#4ade80;display:inline-block;animation:pulse-glow 2s ease-in-out infinite}
@keyframes pulse-glow{0%,100%{opacity:1;box-shadow:0 0 4px #4ade80}50%{opacity:0.5;box-shadow:0 0 12px #4ade80}}
.info-section{padding:100px 0;border-top:1px solid var(--border)}
.info-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:20px;margin-top:48px}
.info-card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-lg);padding:28px;transition:all var(--transition)}
.info-card:hover{border-color:var(--border-hover);background:var(--bg-card-hover)}
.info-card h3{font-size:1rem;font-weight:700;margin-bottom:10px}.info-card p{font-size:0.85rem;color:var(--text-muted);line-height:1.7}
.coming-soon-section{padding:80px 0;border-top:1px solid var(--border)}
.coming-soon-card{text-align:center;background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-lg);padding:48px 32px;max-width:640px;margin:0 auto}
.coming-soon-icon{font-size:3rem;color:var(--text-dim);margin-bottom:20px}
.coming-soon-card h2{font-size:1.75rem;font-weight:800;margin-bottom:12px}
.coming-soon-card p{color:var(--text-muted);font-size:0.9rem;line-height:1.7;max-width:480px;margin:0 auto 24px}
.coming-soon-badge{display:inline-block;font-size:0.75rem;font-weight:700;letter-spacing:2px;text-transform:uppercase;color:var(--text-dim);border:1px solid var(--border);padding:8px 24px;border-radius:100px}
.btn{display:inline-flex;align-items:center;gap:8px;padding:14px 28px;border-radius:var(--radius);font-size:0.9rem;font-weight:600;cursor:pointer;transition:all var(--transition);border:none;font-family:var(--font-sans)}
.btn-primary{background:#fff;color:#000}.btn-primary:hover{background:#ddd;transform:translateY(-1px)}
.btn-ghost{background:transparent;color:var(--text);border:1px solid var(--border)}.btn-ghost:hover{border-color:var(--text-muted)}
.btn-full{width:100%;justify-content:center;margin-top:12px}
.btn-icon{background:none;border:none;color:var(--text-muted);cursor:pointer;padding:6px;border-radius:6px;transition:all var(--transition);font-size:0.9rem}.btn-icon:hover{color:var(--text);background:var(--border)}
.features{padding:100px 0;border-top:1px solid var(--border)}
.section-title{font-size:2.5rem;font-weight:800;letter-spacing:-1.5px;text-align:center;margin-bottom:16px}
.section-sub{text-align:center;color:var(--text-muted);max-width:560px;margin:0 auto 60px;line-height:1.7}
.features-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:20px}
.feature-card{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-lg);padding:32px;transition:all var(--transition)}
.feature-card:hover{border-color:var(--border-hover);background:var(--bg-card-hover);transform:translateY(-2px)}
.feature-icon{width:48px;height:48px;display:flex;align-items:center;justify-content:center;border-radius:12px;background:var(--border);margin-bottom:20px;font-size:1.25rem}
.feature-card h3{font-size:1.1rem;font-weight:700;margin-bottom:10px}.feature-card p{font-size:0.875rem;color:var(--text-muted);line-height:1.7}
.obfuscator{padding:100px 0;border-top:1px solid var(--border)}
.obf-layout{display:grid;grid-template-columns:280px 1fr;gap:20px;margin-top:48px}
.options-panel{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-lg);padding:24px;height:fit-content;position:sticky;top:100px}
.options-panel h3{font-size:0.95rem;font-weight:700;margin-bottom:20px;display:flex;align-items:center;gap:8px}
.option-group{margin-bottom:16px}
.toggle-label{display:flex;align-items:center;justify-content:space-between;font-size:0.85rem;color:var(--text-muted)}
.toggle{position:relative;display:inline-block;width:40px;height:22px;flex-shrink:0}
.toggle input{opacity:0;width:0;height:0}
.toggle-slider{position:absolute;cursor:pointer;inset:0;background:var(--border);border-radius:22px;transition:var(--transition)}
.toggle-slider::before{content:'';position:absolute;height:16px;width:16px;left:3px;bottom:3px;background:#555;border-radius:50%;transition:var(--transition)}
.toggle input:checked+.toggle-slider{background:#444}
.toggle input:checked+.toggle-slider::before{transform:translateX(18px);background:#fff}
.range-label{display:flex;justify-content:space-between;font-size:0.85rem;color:var(--text-muted);margin-bottom:8px}
.range-val{color:var(--text);font-weight:700;font-family:var(--font-mono)}
.range-input{width:100%;-webkit-appearance:none;background:var(--border);height:4px;border-radius:4px;outline:none}
.range-input::-webkit-slider-thumb{-webkit-appearance:none;width:16px;height:16px;border-radius:50%;background:#fff;cursor:pointer}
.version-selector{margin-bottom:20px}
.version-tabs{display:flex;gap:8px;margin-top:8px}
.version-tab{flex:1;padding:10px;border:1px solid var(--border);border-radius:var(--radius);background:transparent;color:var(--text-muted);font-family:var(--font-mono);font-size:0.85rem;font-weight:700;cursor:pointer;transition:all var(--transition);text-align:center}
.version-tab.active{background:#fff;color:#000;border-color:#fff}
.version-tab:hover:not(.active){border-color:var(--text-muted);color:var(--text)}
.code-panels{display:grid;grid-template-columns:1fr 1fr;gap:20px}
.code-panel{background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-lg);overflow:hidden;display:flex;flex-direction:column}
.panel-header{display:flex;align-items:center;justify-content:space-between;padding:14px 20px;border-bottom:1px solid var(--border);font-size:0.8rem;font-weight:600;text-transform:uppercase;letter-spacing:1px;color:var(--text-muted)}
.panel-header span{display:flex;align-items:center;gap:8px}
textarea{width:100%;min-height:500px;background:transparent;color:var(--text);border:none;padding:20px;font-family:var(--font-mono);font-size:0.85rem;line-height:1.7;resize:vertical;outline:none}
textarea::placeholder{color:var(--text-dim)}
.stats-bar{display:flex;gap:32px;justify-content:center;margin-top:24px;padding:16px;background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius)}
.stat-item{font-size:0.85rem;color:var(--text-muted);display:flex;align-items:center;gap:8px}
.stat-item i{color:var(--text)}.stat-item span{color:var(--text);font-weight:600;font-family:var(--font-mono)}
.logs-container{margin-top:20px;background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius-lg);padding:20px}
.logs-container h4{font-size:0.85rem;color:var(--text-muted);margin-bottom:12px;display:flex;align-items:center;gap:8px}
.logs-output{font-family:var(--font-mono);font-size:0.8rem;color:var(--text-muted);line-height:1.8}
.log-line{padding:2px 0}.log-line.info{color:var(--text-muted)}.log-line.success{color:#4ade80}.log-line.error{color:#f87171}
.error-container{margin-top:20px;background:#1a0a0a;border:1px solid #331111;border-radius:var(--radius-lg);padding:20px;color:#f87171;font-family:var(--font-mono);font-size:0.85rem;line-height:1.6}
.api-key-section{padding:100px 0;border-top:1px solid var(--border)}
.api-key-box{max-width:600px;margin:0 auto}
.api-key-form{display:flex;gap:12px}
.input-field{flex:1;background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:14px 18px;color:var(--text);font-family:var(--font-sans);font-size:0.9rem;outline:none;transition:border-color var(--transition)}
.input-field:focus{border-color:var(--text-muted)}
.generated-key{margin-top:16px;display:flex;align-items:center;gap:12px;background:var(--bg-card);border:1px solid var(--border);border-radius:var(--radius);padding:14px 18px}
.generated-key code{flex:1;font-family:var(--font-mono);font-size:0.85rem;color:#4ade80;word-break:break-all}
.legal-page{padding:140px 0 80px}
.legal-updated{text-align:center;color:var(--text-dim);font-size:0.85rem;margin-bottom:48px}
.legal-content{max-width:760px;margin:0 auto}
.legal-content h2{font-size:1.25rem;font-weight:700;margin:36px 0 12px}
.legal-content p{color:var(--text-muted);line-height:1.8;margin-bottom:12px;font-size:0.9rem}
.legal-content strong{color:var(--text)}
.legal-content ul{color:var(--text-muted);margin:8px 0 16px 24px;line-height:1.8;font-size:0.9rem}
.legal-content li{margin-bottom:6px}
footer{padding:40px 0;border-top:1px solid var(--border)}
.footer-content{display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:16px}
.footer-brand{font-weight:800;font-size:1.1rem;display:flex;align-items:center;gap:8px}
.footer-center-links{display:flex;gap:20px}
.footer-center-links a{color:var(--text-muted);font-size:0.85rem;transition:color var(--transition)}
.footer-center-links a:hover{color:var(--text)}
.footer-links a{color:#ff4444;font-weight:600;font-size:0.9rem;display:flex;align-items:center;gap:6px}.footer-links a:hover{color:#ff6666}
.footer-copy{font-size:0.75rem;color:var(--text-dim);text-align:center;margin-top:20px}
.btn-loading{pointer-events:none;opacity:0.7}.btn-loading i{animation:spin 1s linear infinite}
@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
@media(max-width:900px){.obf-layout{grid-template-columns:1fr}.code-panels{grid-template-columns:1fr}.options-panel{position:static}.hero h1{font-size:3rem}.nav-links{gap:16px}.info-grid{grid-template-columns:1fr}.footer-content{flex-direction:column;text-align:center}.footer-center-links{justify-content:center}.live-counters{gap:24px}}
@media(max-width:600px){.nav-links{display:none}.hero-actions{flex-direction:column;align-items:center}.api-key-form{flex-direction:column}.counter-number{font-size:2rem}.live-counters{flex-direction:column;gap:16px}.counter-divider{width:60px;height:1px}}
`
}

function mainJS() {
  return `
(function() {
  'use strict';
  const $ = id => document.getElementById(id);
  const codeInput = $('code-input'), codeOutput = $('code-output');
  const btnObfuscate = $('btn-obfuscate'), btnClear = $('btn-clear'), btnCopy = $('btn-copy');
  const statsBar = $('stats-bar'), logsContainer = $('logs-container'), logsOutput = $('logs-output');
  const errorContainer = $('error-container'), errorOutput = $('error-output');
  const depthSlider = $('opt-loaderVMDepth'), depthVal = $('depth-val');
  const v2DepthSlider = $('v2-loaderVMDepth'), v2DepthVal = $('v2-depth-val');
  const counterEl = $('global-counter'), viewersEl = $('live-viewers');
  const keyLabel = $('key-label'), btnGenKey = $('btn-gen-key');
  const generatedKeyDiv = $('generated-key'), keyValue = $('key-value'), btnCopyKey = $('btn-copy-key');
  const tabV1 = $('tab-v1'), tabV2 = $('tab-v2');
  const v1Options = $('v1-options'), v2Options = $('v2-options');

  let currentVersion = 'v1';

  // Version tabs
  tabV1.addEventListener('click', () => {
    currentVersion = 'v1';
    tabV1.classList.add('active'); tabV2.classList.remove('active');
    v1Options.style.display = ''; v2Options.style.display = 'none';
  });
  tabV2.addEventListener('click', () => {
    currentVersion = 'v2';
    tabV2.classList.add('active'); tabV1.classList.remove('active');
    v2Options.style.display = ''; v1Options.style.display = 'none';
  });

  // Viewer ID
  let viewerId = sessionStorage.getItem('stx_vid');
  if (!viewerId) { viewerId = 'v_' + Math.random().toString(36).substring(2) + Date.now().toString(36); sessionStorage.setItem('stx_vid', viewerId); }

  function animateCounter(el, target) {
    const duration = 1000, start = performance.now();
    const startVal = parseInt(el.textContent.replace(/,/g, '')) || 0;
    if (startVal === target) return;
    function step(now) {
      const p = Math.min((now - start) / duration, 1);
      el.textContent = Math.floor(startVal + (target - startVal) * (1 - Math.pow(1 - p, 3))).toLocaleString();
      if (p < 1) requestAnimationFrame(step);
    }
    requestAnimationFrame(step);
  }

  function sendHeartbeat() {
    fetch('/api/heartbeat', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ vid: viewerId }) })
    .then(r => r.json()).then(d => {
      if (typeof d.liveViewers === 'number') animateCounter(viewersEl, d.liveViewers);
      if (typeof d.totalProtected === 'number') animateCounter(counterEl, d.totalProtected);
    }).catch(() => {});
  }
  sendHeartbeat(); setInterval(sendHeartbeat, 10000);

  depthSlider.addEventListener('input', () => { depthVal.textContent = depthSlider.value; });
  v2DepthSlider.addEventListener('input', () => { v2DepthVal.textContent = v2DepthSlider.value; });

  btnClear.addEventListener('click', () => {
    codeInput.value = ''; codeOutput.value = '';
    statsBar.style.display = 'none'; logsContainer.style.display = 'none'; errorContainer.style.display = 'none';
  });

  btnCopy.addEventListener('click', () => {
    if (codeOutput.value) { navigator.clipboard.writeText(codeOutput.value); btnCopy.innerHTML = '<i class="fas fa-check"></i>'; setTimeout(() => btnCopy.innerHTML = '<i class="fas fa-copy"></i>', 1500); }
  });

  function getV1Options() {
    return {
      useLuaVM: $('opt-useLuaVM').checked, loaderVMDepth: parseInt(depthSlider.value),
      encryptStrings: $('opt-encryptStrings').checked, proxifyLocals: $('opt-proxifyLocals').checked,
      proxifyFunctions: $('opt-proxifyFunctions').checked, antiTamper: $('opt-antiTamper').checked,
      isLuauRuntime: $('opt-isLuauRuntime').checked, controlFlowFlattening: $('opt-controlFlowFlattening').checked,
      minify: $('opt-minify').checked
    };
  }

  function getV2Settings() {
    return {
      encryptStrings: $('v2-encryptStrings').checked, proxifyLocals: $('v2-proxifyLocals').checked,
      proxifyFunctions: $('v2-proxifyFunctions').checked, antiTamper: $('v2-antiTamper').checked,
      controlFlowFlattening: $('v2-controlFlowFlattening').checked, isLuauRuntime: $('v2-isLuauRuntime').checked,
      loaderVMDepth: parseInt(v2DepthSlider.value)
    };
  }

  btnObfuscate.addEventListener('click', async () => {
    const code = codeInput.value.trim();
    if (!code) { codeInput.focus(); return; }

    btnObfuscate.classList.add('btn-loading');
    btnObfuscate.innerHTML = '<i class="fas fa-spinner"></i> Protecting...';
    codeOutput.value = ''; statsBar.style.display = 'none'; logsContainer.style.display = 'none'; errorContainer.style.display = 'none';

    const payload = { code, version: currentVersion };
    if (currentVersion === 'v1') payload.options = getV1Options();
    else payload.v2Settings = getV2Settings();

    try {
      const resp = await fetch('/api/obfuscate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
      const data = await resp.json();

      if (data.success) {
        codeOutput.value = data.code;
        if (data.stats && data.stats.input_bytes) {
          $('stat-input-bytes').textContent = data.stats.input_bytes || 0;
          $('stat-output-bytes').textContent = data.stats.output_bytes || 0;
          $('stat-time').textContent = data.stats.elapsed_seconds || 0;
          statsBar.style.display = 'flex';
        }
        if (data.logs && data.logs.length) {
          logsOutput.innerHTML = data.logs.map(log => '<div class="log-line ' + (log.level||'info') + '">[' + (log.time||'') + '] ' + (log.message||'') + '</div>').join('');
          logsContainer.style.display = 'block';
        }
        if (data.totalProtected) animateCounter(counterEl, data.totalProtected);
      } else {
        errorOutput.innerHTML = '<strong>Error:</strong> ' + (data.error || 'Obfuscation failed. Check your code and try again.');
        errorContainer.style.display = 'block';
      }
    } catch (err) { errorOutput.innerHTML = '<strong>Network Error:</strong> ' + err.message; errorContainer.style.display = 'block'; }

    btnObfuscate.classList.remove('btn-loading');
    btnObfuscate.innerHTML = '<i class="fas fa-shield-halved"></i> Obfuscate';
  });

  btnGenKey.addEventListener('click', async () => {
    const label = keyLabel.value.trim() || 'Untitled';
    btnGenKey.classList.add('btn-loading'); btnGenKey.innerHTML = '<i class="fas fa-spinner"></i> Generating...';
    try {
      const resp = await fetch('/api/keys/generate', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ label }) });
      const data = await resp.json();
      if (data.success) { keyValue.textContent = data.key; generatedKeyDiv.style.display = 'flex'; }
    } catch (err) { alert('Failed: ' + err.message); }
    btnGenKey.classList.remove('btn-loading'); btnGenKey.innerHTML = '<i class="fas fa-key"></i> Generate Key';
  });

  btnCopyKey.addEventListener('click', () => {
    navigator.clipboard.writeText(keyValue.textContent);
    btnCopyKey.innerHTML = '<i class="fas fa-check"></i>'; setTimeout(() => btnCopyKey.innerHTML = '<i class="fas fa-copy"></i>', 1500);
  });

  codeInput.addEventListener('keydown', (e) => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') { e.preventDefault(); btnObfuscate.click(); } });
})();
`
}

export default app
