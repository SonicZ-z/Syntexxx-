# Syntexxx — Lua Obfuscator

## Project Overview
- **Name**: Syntexxx
- **Goal**: Advanced Lua/Luau script obfuscation platform with military-grade protection
- **Live**: https://syntexxx.pages.dev

## Features
- **LuaVM Virtualization** — Custom bytecode with dynamic opcode shuffling
- **String Encryption** — All string literals encrypted, decoded at runtime
- **Control Flow Flattening** — State-machine driven basic blocks
- **Anti-Tamper** — Environment verification and anti-hooking
- **Proxy Wrapping** — Metatable proxy containers for locals and functions
- **Minification** — Debug symbol stripping and identifier mangling
- **API Key System** — Generate `stx_` prefixed keys for API access
- **API Documentation** — Full REST API docs at `/api-docs`

## URLs
- **Production**: https://syntexxx.pages.dev
- **API Docs**: https://syntexxx.pages.dev/api-docs
- **Obfuscator**: https://syntexxx.pages.dev/#obfuscator

## API Endpoints
| Method | Path | Description |
|--------|------|-------------|
| POST | `/api/obfuscate` | Obfuscate Lua code (web UI) |
| POST | `/api/v1/obfuscate` | Obfuscate via API key (Bearer auth) |
| POST | `/api/keys/generate` | Generate a new API key |

## Design
- **Black & White** minimal design with Inter + JetBrains Mono typography
- Noise overlay texture for premium feel
- Grid-based hero with gradient text
- All responsive breakpoints covered

## Watermark
All obfuscated output includes only:
```
--[[ Syntexxx.of.to ]]--
```

## Tech Stack
- **Backend**: Hono (Cloudflare Workers)
- **Frontend**: Vanilla HTML/CSS/JS with Tailwind-inspired design
- **Deployment**: Cloudflare Pages
- **API Secret**: Stored as Cloudflare Pages secret (never exposed)

## Credits
- **SonicZ Dev** — https://youtube.com/@sonicz-dev

## Deployment
- **Platform**: Cloudflare Pages
- **Status**: ✅ Active
- **Last Updated**: 2026-09-04
